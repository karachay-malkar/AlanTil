import { getInterfaceLocale, msg } from "../../shared/i18n/index.js?v=13.9.0";
import { problemWordRows, recentTestSummariesForWords, testSummariesForWords, wordProgressSummary } from "../../shared/progress/word-progress-store.js?v=13.9.0";
import { wordFavorites } from "../../shared/state/word-favorites.js?v=13.9.0";
import { escapeHtml } from "../../shared/ui/html.js?v=13.9.0";
import { bindOverflowMarquees, renderOverflowMarquee } from "../../shared/ui/overflow-marquee.js?v=13.10.12";
import { renderSegmentedProgress } from "../../shared/ui/segmented-progress.js?v=13.9.0";
import { renderStarButton } from "../../shared/ui/word-renderers.js?v=13.9.0";
import { getHiddenSet, setHiddenSet } from "../learn/state.js?v=13.9.0";

function storageKey(station) {
  return station.selectionSetId || station.setId || station.key;
}

function masteryMark(percent) {
  if (percent >= 100) return { level: 3, label: msg("stage.iii_znak"), symbol: "⌃⌃⌃" };
  if (percent >= 90) return { level: 2, label: msg("stage.ii_znak"), symbol: "⌃⌃" };
  if (percent >= 80) return { level: 1, label: msg("stage.i_znak"), symbol: "⌃" };
  return { level: 0, label: msg("stage.ne_sdan"), symbol: "—" };
}

function resultCard(result) {
  const mark = masteryMark(result.percent);
  const date = result.date ? new Intl.DateTimeFormat(getInterfaceLocale(), { day: "2-digit", month: "2-digit" }).format(new Date(result.date)) : "";
  return `<div class="stationAttempt ${result.percent >= 80 ? "isPassed" : "isFailed"}">
    <strong>${result.percent}%</strong>
    <span>${escapeHtml(mark.label)}</span>
    ${date ? `<small>${escapeHtml(date)}</small>` : ""}
  </div>`;
}

function problemRows(words) {
  const rows = problemWordRows(words, 7);
  if (!rows.length) return `<div class="stationEmptyState">${msg("stage.poka_nedostatochno_dannyh")}</div>`;
  return `<div class="stationProblemList">
    <div class="stationProblemHead"><span>${msg("stage.slovo")}</span><span>${msg("stage.pokazy")}</span><span>${msg("stage.ne_znayu")}</span><span>${msg("stage.zatrudnenie")}</span><span></span></div>
    ${rows.map(({ word, progress, evaluated, unknownRate }) => `<div class="stationProblemRow">
      <span class="stationProblemWord">${escapeHtml(word.word)}</span>
      <span>${evaluated}</span>
      <span>${progress.unknown_count}</span>
      <span>${unknownRate}%</span>
      ${renderStarButton(word.id, `data-stat-favorite="${escapeHtml(word.id)}"`)}
    </div>`).join("")}
  </div>`;
}

export function renderStationView(context, station, {
  signal,
  onStartStudy,
  onStartTest,
} = {}) {
  const allWords = Array.isArray(station.words) ? station.words : [];
  const selectionId = storageKey(station);
  let activeTab = "menu";
  let hidden = getHiddenSet(station.dictionaryId, station.groupId, selectionId);
  let menuScrollTop = 0;
  let studyMode = "kb";
  let stopMarquees = () => {};

  context.shell.setHeaderContent?.({
    title: station.name,
    subtitle: station.groupName,
    logo: false,
    brand: false,
  });

  const stationWordIds = new Set(allWords.map((word) => String(word.id)));

  function activeWords() {
    return allWords.filter((word) => !hidden.has(String(word.id)));
  }

  function replaceCurrentStationHidden(nextIds) {
    stationWordIds.forEach((wordId) => hidden.delete(wordId));
    (nextIds || []).forEach((wordId) => hidden.add(String(wordId)));
  }

  function persist() {
    setHiddenSet(station.dictionaryId, station.groupId, selectionId, hidden);
  }

  function scrollingLine(value, className) {
    return renderOverflowMarquee(value, {
      clipClass: `${className} stationTextClip`,
      trackClass: "stationMarquee",
    });
  }

  function staticLine(value, className) {
    const text = String(value || "");
    return `<span class="${className} stationTextClip stationStaticText" title="${escapeHtml(text)}">${escapeHtml(text)}</span>`;
  }

  function wireVisibleMarquees() {
    stopMarquees();
    stopMarquees = bindOverflowMarquees(context.root, {
      signal,
      scrollRoot: context.root.querySelector(".stationWordList"),
    });
  }

  function wireTabButtons() {
    context.root.querySelectorAll("[data-station-tab]").forEach((button) => {
      button.addEventListener("click", () => {
        const next = button.dataset.stationTab === "statistics" ? "statistics" : "menu";
        if (next === activeTab) return;
        const list = context.root.querySelector(".stationWordList");
        if (list) menuScrollTop = list.scrollTop;
        activeTab = next;
        draw();
      }, { signal });
    });
  }

  function renderMenu() {
    const selected = activeWords();
    return `<section class="stationPane stationMenuPane" data-station-pane="menu">
      <div class="stationMenuToolbar">
        <span class="stationMenuActions">
          <button class="textAction" type="button" data-show-all>${msg("stage.pokazat_vse")}</button>
          <span aria-hidden="true">·</span>
          <button class="textAction" type="button" data-hide-all>${msg("stage.skryt_vse")}</button>
        </span>
        <span class="stationSelectionCount">${selected.length}/${allWords.length}</span>
      </div>
      <div class="contentList stationWordList">
        ${allWords.map((word) => `<div class="contentListRow stationWordRow" data-station-word="${escapeHtml(word.id)}">
          <label class="stationWordToggle bracketCheckbox">
            <input class="contentListCheckbox" type="checkbox" ${hidden.has(String(word.id)) ? "" : "checked"} aria-label="${msg("stage.dobavit_slovo_v_obuchenie")}" />
            <span class="bracketCheckboxMark" aria-hidden="true"></span>
          </label>
          <span class="contentListMain"><span data-station-line>${staticLine(word.word, "contentListPrimary")}</span><span data-station-line>${scrollingLine(word.trans, "contentListSecondary")}</span></span>
          ${renderStarButton(word.id, `data-station-favorite="${escapeHtml(word.id)}"`)}
        </div>`).join("")}
      </div>
      <footer class="stationLaunchPanel">
        <div class="stationDirectionControl">
          <span>${msg("stage.napravlenie")}</span>
          <div class="segmentControl stationDirectionToggle" role="radiogroup" aria-label="${msg("stage.napravlenie_obucheniya")}">
            <button class="segmentOption ${studyMode === "kb" ? "active" : ""}" type="button" role="radio" aria-checked="${studyMode === "kb"}" data-station-mode="kb">${msg("stage.alan_rus")}</button>
            <button class="segmentOption ${studyMode === "ru" ? "active" : ""}" type="button" role="radio" aria-checked="${studyMode === "ru"}" data-station-mode="ru">${msg("stage.rus_alan")}</button>
          </div>
        </div>
        <div class="stationLaunchActions">
          <button class="btn stationStudyButton" type="button" data-station-study ${selected.length ? "" : "disabled"}>${msg("stage.uchit_slova")}</button>
          <button class="btn actionPrimary stationTestButton" type="button" data-station-test>${msg("stage.zavershit_etap_test")}</button>
        </div>
      </footer>
    </section>`;
  }

  function renderStatistics() {
    const summary = wordProgressSummary(allWords);
    const recent = recentTestSummariesForWords(allWords, 3);
    const attempts = testSummariesForWords(allWords);
    const best = attempts.reduce((value, row) => Math.max(value, Number(row.percent || 0)), 0);
    const mark = masteryMark(best);
    return `<section class="stationPane stationStatisticsPane" data-station-pane="statistics">
      <div class="stationStatsSummary">
        <div class="stationMasteryBlock">
          <span class="stationStatLabel">${msg("stage.osvoeno_slov_2")}</span>
          <strong>${summary.mastered}/${summary.total}</strong>
          ${renderSegmentedProgress({ value: summary.percent, segments: 10, label: msg("stage.osvoeno_slov", { percent: summary.percent }), className: "stationMasteryProgress" })}
        </div>
        <div class="stationMasteryBadge" aria-label="${escapeHtml(mark.label)}"><span>${escapeHtml(mark.symbol)}</span><small>${escapeHtml(mark.label)}</small></div>
      </div>
      <div class="stationMetricGrid">
        <div><strong>${attempts.length}</strong><span>${msg("stage.popytok")}</span></div>
        <div><strong>${best}%</strong><span>${msg("stage.luchshiy_rezultat")}</span></div>
        <div><strong>${summary.review}</strong><span>${msg("stage.trebuyut_povtoreniya")}</span></div>
      </div>
      <section class="stationStatsSection">
        <h2 class="stationStatsHeading">${msg("stage.poslednie_rezultaty")}</h2>
        <div class="stationAttempts">${recent.length ? recent.map(resultCard).join("") : `<div class="stationEmptyState">${msg("stage.testy_esche_ne_prohodilis")}</div>`}</div>
      </section>
      <section class="stationStatsSection">
        <h2 class="stationStatsHeading">${msg("stage.problemnye_slova")}</h2>
        ${problemRows(allWords)}
      </section>
    </section>`;
  }

  function wireMenu() {
    const list = context.root.querySelector(".stationWordList");
    if (list) list.scrollTop = menuScrollTop;

    function updateSelectionState() {
      const selectedCount = activeWords().length;
      const count = context.root.querySelector(".stationSelectionCount");
      if (count) count.textContent = `${selectedCount}/${allWords.length}`;
      const studyButton = context.root.querySelector("[data-station-study]");
      if (studyButton) studyButton.disabled = selectedCount === 0;
    }

    list?.querySelectorAll("[data-station-word]").forEach((row) => {
      row.querySelector("input")?.addEventListener("change", (event) => {
        if (event.currentTarget.checked) hidden.delete(String(row.dataset.stationWord));
        else hidden.add(String(row.dataset.stationWord));
        persist();
        updateSelectionState();
      }, { signal });
    });
    context.root.querySelector("[data-show-all]")?.addEventListener("click", () => {
      if (list) menuScrollTop = list.scrollTop;
      replaceCurrentStationHidden([]);
      persist();
      draw();
    }, { signal });
    context.root.querySelector("[data-hide-all]")?.addEventListener("click", () => {
      if (list) menuScrollTop = list.scrollTop;
      replaceCurrentStationHidden(allWords.map((word) => word.id));
      persist();
      draw();
    }, { signal });
    context.root.querySelectorAll("[data-station-favorite]").forEach((button) => {
      button.addEventListener("click", () => button.classList.toggle("on", wordFavorites.toggle(button.dataset.stationFavorite)), { signal });
    });
    context.root.querySelectorAll("[data-station-mode]").forEach((button) => {
      button.addEventListener("click", () => {
        studyMode = button.dataset.stationMode === "ru" ? "ru" : "kb";
        context.root.querySelectorAll("[data-station-mode]").forEach((item) => {
          const active = item.dataset.stationMode === studyMode;
          item.classList.toggle("active", active);
          item.setAttribute("aria-checked", String(active));
        });
      }, { signal });
    });
    context.root.querySelector("[data-station-study]")?.addEventListener("click", () => onStartStudy?.(studyMode, activeWords()), { signal });
    context.root.querySelector("[data-station-test]")?.addEventListener("click", () => onStartTest?.(studyMode), { signal });
    wireVisibleMarquees();
  }

  function wireStatistics() {
    context.root.querySelectorAll("[data-stat-favorite]").forEach((button) => {
      button.addEventListener("click", () => button.classList.toggle("on", wordFavorites.toggle(button.dataset.statFavorite)), { signal });
    });
  }

  function draw() {
    stopMarquees();
    stopMarquees = () => {};
    context.shell.appShell.dataset.stationPane = activeTab;
    context.root.innerHTML = `<section class="view screen stationView">
      <div class="stationViewTabs" role="tablist" aria-label="${msg("stage.razdel_etapa")}">
        <button class="tabAction stationViewTab ${activeTab === "menu" ? "active" : ""}" type="button" role="tab" aria-selected="${activeTab === "menu"}" data-station-tab="menu">${msg("stage.menyu")}</button>
        <button class="tabAction stationViewTab ${activeTab === "statistics" ? "active" : ""}" type="button" role="tab" aria-selected="${activeTab === "statistics"}" data-station-tab="statistics">${msg("stage.statistika")}</button>
      </div>
      ${activeTab === "menu" ? renderMenu() : renderStatistics()}
    </section>`;
    wireTabButtons();
    if (activeTab === "menu") wireMenu();
    else wireStatistics();
  }

  draw();
}
